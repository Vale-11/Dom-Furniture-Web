const express = require('express');
const cors = require('cors');
const sql = require('mssql');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// SQL Server Config
const config = {
    user: 'your_username',       // e.g., 'sa' (SQL Server admin)
    password: 'your_password',
    server: 'localhost',         // or '.\SQLEXPRESS'
    database: 'DomwoodDB',
    options: { encrypt: false }  // Disable encryption for local dev
};

// Image Upload Setup
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

// Admin Login
app.post('/api/admin/login', async (req, res) => {
    const { password } = req.body;
    try {
        const pool = await sql.connect(config);
        const result = await pool.request()
            .input('username', sql.NVarChar, 'admin')
            .query('SELECT Password FROM Admins WHERE Username = @username');

        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'Admin not found' });
        }

        const hashedPassword = result.recordset[0].Password;
        const isMatch = await bcrypt.compare(password, hashedPassword);

        if (!isMatch) {
            return res.status(401).json({ error: 'Invalid password' });
        }

        res.json({ message: 'Login successful' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Add Product
app.post('/api/products', upload.array('images', 5), async (req, res) => {
    const { name, description, category, price } = req.body;
    const images = req.files.map(file => file.path).join(',');

    try {
        const pool = await sql.connect(config);
        await pool.request()
            .input('name', sql.NVarChar, name)
            .input('description', sql.NVarChar, description)
            .input('category', sql.NVarChar, category)
            .input('price', sql.Decimal, price)
            .input('images', sql.NVarChar, images)
            .query(`
                INSERT INTO Products (Name, Description, Category, Price, ImagePaths)
                VALUES (@name, @description, @category, @price, @images)
            `);

        res.json({ message: 'Product added successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get All Products
app.get('/api/products', async (req, res) => {
    try {
        const pool = await sql.connect(config);
        const result = await pool.request().query('SELECT * FROM Products');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
require('dotenv').config();
const adminPassword = process.env.ADMIN_PASSWORD;
document.addEventListener('DOMContentLoaded', function() {
    // ===== CONSTANTS =====
    const ADMIN_PASSWORD = "domwood123"; // In production, use server-side auth
    const DEFAULT_IMAGE = 'https://picsum.photos/300/300?random=';

    // ===== DOM ELEMENTS =====
    // Admin elements
    const adminLoginBtn = document.getElementById('adminLoginBtn');
    const adminLoginModal = document.getElementById('adminLoginModal');
    const adminPanel = document.getElementById('adminPanel');
    const closeLogin = document.querySelector('.close-login');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const adminPassword = document.getElementById('adminPassword');
    
    // Product form elements
    const productNameInput = document.getElementById('productName');
    const productDescInput = document.getElementById('productDescription');
    const productCategoryInput = document.getElementById('productCategory');
    const productPriceInput = document.getElementById('productPrice');
    const productImagesInput = document.getElementById('productImages');
    const addProductBtn = document.getElementById('addProductBtn');
    
    // Image upload elements
    const bulkImageUpload = document.getElementById('bulkImageUpload');
    const imageCategorySelect = document.getElementById('imageCategory');
    const uploadImagesBtn = document.getElementById('uploadImagesBtn');
    
    // Main website elements
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const closeBtn = document.getElementById('closeBtn');
    const navLinks = document.querySelectorAll('.nav-link:not(.menu-products > .nav-link)');
    const productLink = document.querySelector('.menu-products > .nav-link');
    const pages = document.querySelectorAll('.page');
    const body = document.body;
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    const menuProducts = document.querySelector('.menu-products');
    const productPreview = document.querySelector('.product-preview');
    const productsGrid = document.getElementById('productsGrid');
    const productList = document.getElementById('productList');
    const imageGallery = document.getElementById('imageGallery');
    const currentYearElement = document.getElementById('current-year');

    // ===== STATE MANAGEMENT =====
    let isLoggedIn = localStorage.getItem('adminLoggedIn') === 'true';

    // ===== UTILITY FUNCTIONS =====
    function showToast(message, isError = false) {
        Toastify({
            text: message,
            duration: 3000,
            close: true,
            gravity: "top",
            position: "right",
            backgroundColor: isError ? "#f44336" : "#4CAF50",
        }).showToast();
    }

    // ===== ADMIN FUNCTIONALITY =====
    function initAdminPanel() {
        if (!adminPanel || !adminLoginBtn || !adminLoginModal) return;

        // Set initial state
        adminLoginBtn.style.display = 'none';
        adminPanel.style.display = 'none';

        // Show login button after delay if not logged in
        if (!isLoggedIn) {
            setTimeout(() => {
                if (adminLoginBtn) adminLoginBtn.style.display = 'block';
            }, 3000);
        } else {
            showAdminPanel();
            loadAdminData();
        }

        // Initialize admin event listeners
        initAdminEventListeners();
        initAdminTabs();
        initAdminProductManagement();
    }

    function initAdminEventListeners() {
        // Login button shows modal
        adminLoginBtn?.addEventListener('click', showLoginModal);
        
        // Close button hides modal
        closeLogin?.addEventListener('click', hideLoginModal);
        
        // Login form submission
        loginBtn?.addEventListener('click', handleLogin);
        
        // Logout button
        logoutBtn?.addEventListener('click', handleLogout);
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === adminLoginModal) {
                hideLoginModal();
            }
        });

        // Handle Enter key in password field
        adminPassword?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleLogin();
            }
        });
    }

    function showLoginModal() {
        if (adminLoginModal) {
            adminLoginModal.style.display = 'block';
            adminPassword.focus();
        }
    }

    function hideLoginModal() {
        if (adminLoginModal) {
            adminLoginModal.style.display = 'none';
            adminPassword.value = '';
        }
    }

    function handleLogin() {
        if (!adminPassword) return;

        if (adminPassword.value === ADMIN_PASSWORD) {
            localStorage.setItem('adminLoggedIn', 'true');
            isLoggedIn = true;
            hideLoginModal();
            showAdminPanel();
            showToast('Admin login successful');
            loadAdminData();
        } else {
            showToast('Invalid password', true);
            adminPassword.focus();
        }
    }

    function handleLogout() {
        localStorage.removeItem('adminLoggedIn');
        isLoggedIn = false;
        hideAdminPanel();
        showToast('Logged out successfully');
        
        // Hide login button after delay
        setTimeout(() => {
            if (adminLoginBtn) adminLoginBtn.style.display = 'block';
        }, 3000);
    }

    function showAdminPanel() {
        if (adminPanel && adminLoginBtn) {
            adminPanel.style.display = 'block';
            adminLoginBtn.style.display = 'none';
        }
    }

    function hideAdminPanel() {
        if (adminPanel && adminLoginBtn) {
            adminPanel.style.display = 'none';
        }
    }

    function initAdminTabs() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.admin-tab-content');
        
        tabBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                
                // Update active tab button
                tabBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Show corresponding tab content
                tabContents.forEach(content => {
                    content.classList.remove('active');
                    if (content.id === `${tabId}Tab`) {
                        content.classList.add('active');
                    }
                });
            });
        });
    }

    function initAdminProductManagement() {
        // Add product button
        addProductBtn?.addEventListener('click', async function() {
            if (!isLoggedIn) {
                showToast('Please login as admin first', true);
                return;
            }

            const name = productNameInput?.value;
            const description = productDescInput?.value;
            const category = productCategoryInput?.value;
            const price = productPriceInput?.value;
            const imageFiles = productImagesInput?.files;

            if (!name || !description || !category || !price) {
                showToast('Please fill all required fields', true);
                return;
            }

            try {
                // Use uploaded images or default image
                let imageUrls = [];
                if (imageFiles && imageFiles.length > 0) {
                    imageUrls = await uploadImages(imageFiles);
                } else {
                    // Fallback to default image
                    imageUrls = [DEFAULT_IMAGE + Date.now()];
                }

                const productData = { 
                    name, 
                    description, 
                    category, 
                    price, 
                    images: imageUrls 
                };
                
                saveProduct(productData);
                showToast('Product added successfully!');
                
                // Clear form
                if (productNameInput) productNameInput.value = '';
                if (productDescInput) productDescInput.value = '';
                if (productCategoryInput) productCategoryInput.value = '';
                if (productPriceInput) productPriceInput.value = '';
                if (productImagesInput) productImagesInput.value = '';
                
                // Refresh displays
                loadProducts();
                loadProductPreview();
                loadProductsPage();
            } catch (error) {
                console.error('Error adding product:', error);
                showToast('Error adding product', true);
            }
        });

        // Image upload button
        uploadImagesBtn?.addEventListener('click', async function() {
            if (!isLoggedIn) {
                showToast('Please login as admin first', true);
                return;
            }

            const files = bulkImageUpload?.files;
            const category = imageCategorySelect?.value;

            if (!files || files.length === 0) {
                showToast('Please select at least one image', true);
                return;
            }

            try {
                const imageUrls = await uploadImages(files, category);
                saveImages(imageUrls, category);
                showToast(`${files.length} images uploaded successfully!`);
                loadGalleryImages(category);
                if (bulkImageUpload) bulkImageUpload.value = '';
            } catch (error) {
                console.error('Error uploading images:', error);
                showToast('Error uploading images', true);
            }
        });
    }

    // ===== DATA MANAGEMENT =====
    async function uploadImages(files, category = 'products') {
        // Simulate upload delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Return mock URLs (replace with actual upload in production)
        return Array.from(files).map((_, i) => 
            `${DEFAULT_IMAGE}${Date.now()}${i}&category=${category}`);
    }

    function saveProduct(productData) {
        const products = JSON.parse(localStorage.getItem('domwood-products')) || [];
        
        // Ensure images array exists
        if (!productData.images || !Array.isArray(productData.images)) {
            productData.images = [DEFAULT_IMAGE + Date.now()];
        }
        
        products.push(productData);
        localStorage.setItem('domwood-products', JSON.stringify(products));
    }

    function saveImages(imageUrls, category) {
        const images = JSON.parse(localStorage.getItem('domwood-images')) || {};
        if (!images[category]) images[category] = [];
        images[category].push(...imageUrls);
        localStorage.setItem('domwood-images', JSON.stringify(images));
    }

    function loadAdminData() {
        if (!isLoggedIn) return;
        
        loadProducts();
        loadGalleryImages('chairs');
        loadProductPreview();
        loadProductsPage();
    }

    function loadProducts() {
        const products = JSON.parse(localStorage.getItem('domwood-products')) || [];
        
        if (!productList) return;
        
        productList.innerHTML = '<h4>Existing Products</h4>';
        
        if (products.length === 0) {
            productList.innerHTML += '<p>No products found</p>';
            return;
        }
        
        products.forEach((product, index) => {
            const productItem = document.createElement('div');
            productItem.className = 'product-item-admin';
            
            // Use first image or default
            const imgUrl = product.images?.[0] || DEFAULT_IMAGE + index;
            
            productItem.innerHTML = `
                <div class="admin-product-image">
                    <img src="${imgUrl}" alt="${product.name}" 
                         onerror="this.src='${DEFAULT_IMAGE}${index}'">
                </div>
                <div class="admin-product-info">
                    <h5>${product.name || 'Unnamed Product'}</h5>
                    <p>${product.description || 'No description'}</p>
                    <p><strong>Category:</strong> ${product.category || 'Uncategorized'}</p>
                    <p><strong>Price:</strong> $${product.price || '0.00'}</p>
                </div>
                <div class="admin-product-actions">
                    <button onclick="editProduct(${index})">Edit</button>
                    <button onclick="deleteProduct(${index})">Delete</button>
                </div>
            `;
            productList.appendChild(productItem);
        });
    }

    function loadGalleryImages(category) {
        const images = JSON.parse(localStorage.getItem('domwood-images')) || {};
        
        if (!imageGallery) return;
        
        imageGallery.innerHTML = '';
        
        if (!images[category] || images[category].length === 0) {
            imageGallery.innerHTML = '<p>No images found for this category</p>';
            return;
        }
        
        images[category].forEach((imgUrl, index) => {
            const imgContainer = document.createElement('div');
            imgContainer.className = 'gallery-item';
            imgContainer.innerHTML = `
                <img src="${imgUrl}" alt="Gallery image ${index + 1}"
                     onerror="this.src='${DEFAULT_IMAGE}${index}'">
                <button onclick="deleteImage('${category}', ${index})">Delete</button>
            `;
            imageGallery.appendChild(imgContainer);
        });
    }

    function loadProductPreview() {
        const products = JSON.parse(localStorage.getItem('domwood-products')) || [];
        
        if (!productPreview) return;
        
        productPreview.innerHTML = '';
        
        // Show first 3 products in preview
        products.slice(0, 3).forEach((product, index) => {
            const imgUrl = product.images?.[0] || DEFAULT_IMAGE + index;
            
            const previewItem = document.createElement('div');
            previewItem.className = 'product-preview-item';
            previewItem.innerHTML = `
                <img src="${imgUrl}" alt="${product.name}"
                     onerror="this.src='${DEFAULT_IMAGE}${index}'">
                <p>${product.name || 'Product'}</p>
            `;
            previewItem.addEventListener('click', () => {
                navigateToPage('products');
            });
            productPreview.appendChild(previewItem);
        });
    }

    function loadProductsPage() {
        const products = JSON.parse(localStorage.getItem('domwood-products')) || [];
        
        if (!productsGrid) return;
        
        productsGrid.innerHTML = '';
        
        products.forEach((product, index) => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            
            // Use first image or default
            const imgUrl = product.images?.[0] || DEFAULT_IMAGE + index;
            
            productCard.innerHTML = `
                <div class="product-image-container">
                    <img src="${imgUrl}" alt="${product.name}"
                         onerror="this.src='${DEFAULT_IMAGE}${index}'">
                </div>
                <div class="product-info">
                    <h3>${product.name || 'Unnamed Product'}</h3>
                    <p class="product-description">${product.description || 'No description available'}</p>
                    <p class="product-price">$${product.price || '0.00'}</p>
                </div>
            `;
            
            productsGrid.appendChild(productCard);
            
            // Add intersection observer for animation
            productCard.style.opacity = '0';
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.animation = 'fadeIn 0.8s ease forwards';
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            observer.observe(productCard);
        });
    }

    // ===== MAIN WEBSITE FUNCTIONALITY =====
    function initMainWebsite() {
        // Create overlay element
        const overlay = document.createElement('div');
        overlay.className = 'overlay';
        document.body.appendChild(overlay);

        // Initialize navigation
        initNavigation(overlay);
        
        // Initialize search
        if (searchForm && searchInput && searchResults) {
            initSearch();
        }
        
        // Initialize product preview
        if (menuProducts && productPreview) {
            initProductPreview();
        }
        
        // Set current year in footer
        if (currentYearElement) {
            currentYearElement.textContent = new Date().getFullYear();
        }
        
        // Make sure home page is active by default
        const homePage = document.getElementById('home');
        if (homePage) {
            homePage.classList.add('active');
        }
        
        // Load products page initially
        loadProductsPage();
    }

    function initNavigation(overlay) {
        function toggleMenu() {
            navMenu.classList.toggle('active');
            overlay.classList.toggle('active');
            body.classList.toggle('no-scroll');
        }

        // Hamburger menu
        hamburger?.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleMenu();
        });

        // Close button
        closeBtn?.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleMenu();
        });

        // Overlay click
        overlay.addEventListener('click', toggleMenu);

        // Navigation links
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                navigateToPage(this.getAttribute('data-page'));
                toggleMenu();
            });
        });

        // Product link
        productLink?.addEventListener('click', function(e) {
            e.preventDefault();
            navigateToPage(this.getAttribute('data-page'));
            toggleMenu();
        });

        // Close menu when clicking outside or pressing ESC
        document.addEventListener('click', function(e) {
            if (navMenu && !navMenu.contains(e.target) && e.target !== hamburger) {
                navMenu.classList.remove('active');
                overlay.classList.remove('active');
                body.classList.remove('no-scroll');
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                navMenu.classList.remove('active');
                overlay.classList.remove('active');
                body.classList.remove('no-scroll');
            }
        });
    }

    function navigateToPage(pageId) {
        // Hide all pages
        pages.forEach(page => {
            page.classList.remove('active');
        });
        
        // Show selected page
        const targetPage = document.getElementById(pageId);
        if (targetPage) {
            targetPage.classList.add('active');
        }
        
        // Scroll to top
        window.scrollTo(0, 0);
        
        // Reload products if navigating to products page
        if (pageId === 'products') {
            loadProductsPage();
        }
    }

    function initProductPreview() {
        function handleProductPreview() {
            if (window.innerWidth > 992) {
                // Desktop behavior - hover
                menuProducts.addEventListener('mouseenter', () => {
                    productPreview.style.display = 'grid';
                });
                
                menuProducts.addEventListener('mouseleave', () => {
                    productPreview.style.display = 'none';
                });
            } else {
                // Mobile behavior - click toggle
                let isPreviewVisible = false;
                
                menuProducts.addEventListener('click', (e) => {
                    if (e.target.classList.contains('nav-link')) {
                        e.preventDefault();
                        isPreviewVisible = !isPreviewVisible;
                        productPreview.style.display = isPreviewVisible ? 'grid' : 'none';
                    }
                });
            }
        }

        handleProductPreview();
        window.addEventListener('resize', handleProductPreview);
    }

    // ===== SEARCH FUNCTIONALITY =====
    function initSearch() {
        let searchData = [];
        let searchInitialized = false;
        
        function initSearchData() {
            try {
                const allPages = document.querySelectorAll('.page');
                searchData = [];
                
                allPages.forEach(page => {
                    const pageId = page.id;
                    const searchableElements = page.querySelectorAll(
                        '[data-searchable], h1, h2, h3, h4, h5, h6, p:not(.search-no-results):not(.search-error), li'
                    );
                    
                    Array.from(searchableElements)
                        .filter(el => el.textContent.trim().length > 0)
                        .forEach(el => {
                            let heading = '';
                            let currentEl = el.previousElementSibling;
                            while (currentEl) {
                                if (currentEl.tagName.match(/^H[1-6]$/)) {
                                    heading = currentEl.textContent.trim();
                                    break;
                                }
                                currentEl = currentEl.previousElementSibling;
                            }
                            
                            searchData.push({
                                id: el.id || `${el.tagName}-${Math.random().toString(36).slice(2, 9)}`,
                                title: el.dataset.searchTitle || 
                                      (heading ? `${heading} - ${el.textContent.trim().slice(0, 30)}` : 
                                      el.textContent.trim().slice(0, 50)),
                                content: el.textContent.trim(),
                                element: el,
                                page: pageId,
                                tagName: el.tagName
                            });
                        });
                });
                
                searchInitialized = true;
            } catch (error) {
                console.error('Error initializing search data:', error);
            }
        }

        function performSearch(query) {
            if (!searchInitialized) return;
            
            if (!query || query.trim().length < 2) {
                searchResults.innerHTML = '';
                searchResults.style.display = 'none';
                return;
            }
            
            const queryLower = query.toLowerCase().trim();
            const queryTerms = queryLower.split(/\s+/).filter(term => term.length > 1);
            
            if (queryTerms.length === 0) {
                searchResults.innerHTML = '<div class="search-no-results">Please enter at least 2 characters</div>';
                searchResults.style.display = 'block';
                return;
            }
            
            // Score results based on match quality
            const scoredResults = searchData.map(item => {
                const contentLower = (item.title + ' ' + item.content).toLowerCase();
                let score = 0;
                
                // Exact match boosts score
                if (contentLower.includes(queryLower)) {
                    score += 50;
                }
                
                // Count term matches
                queryTerms.forEach(term => {
                    const termCount = (contentLower.match(new RegExp(term, 'g')) || []).length;
                    score += termCount * 5;
                    
                    // Boost score for matches in title or headings
                    if (item.title.toLowerCase().includes(term) || item.tagName.match(/^H[1-6]$/)) {
                        score += 10;
                    }
                });
                
                return { ...item, score };
            })
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score);
            
            displayResults(scoredResults, query);
        }

        function displayResults(results, query) {
            searchResults.innerHTML = '';
            
            if (results.length === 0) {
                searchResults.innerHTML = `
                    <div class="search-no-results">
                        No results found for "${query}"
                        <div class="search-suggestions">
                            Try different keywords or check our 
                            <a href="#" data-page="products" class="search-suggestion-link">products</a> 
                            and <a href="#" data-page="services" class="search-suggestion-link">services</a>.
                        </div>
                    </div>
                `;
                
                // Add click handlers to suggestion links
                document.querySelectorAll('.search-suggestion-link').forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        navigateToPage(this.getAttribute('data-page'));
                        searchResults.style.display = 'none';
                        searchInput.value = '';
                    });
                });
                
                searchResults.style.display = 'block';
                return;
            }
            
            const resultsList = document.createElement('ul');
            resultsList.className = 'search-results-list';
            
            // Group results by page
            const resultsByPage = {};
            results.forEach(item => {
                if (!resultsByPage[item.page]) {
                    resultsByPage[item.page] = [];
                }
                resultsByPage[item.page].push(item);
            });
            
            // Display up to 10 best results
            let displayedCount = 0;
            const MAX_RESULTS = 10;
            
            for (const [pageId, pageResults] of Object.entries(resultsByPage)) {
                if (displayedCount >= MAX_RESULTS) break;
                
                const pageHeader = document.createElement('li');
                pageHeader.className = 'search-page-header';
                const pageTitleElement = document.getElementById(pageId)?.querySelector('h1, h2');
                pageHeader.textContent = pageTitleElement?.textContent || pageId;
                resultsList.appendChild(pageHeader);
                
                for (const item of pageResults) {
                    if (displayedCount >= MAX_RESULTS) break;
                    
                    const li = document.createElement('li');
                    const a = document.createElement('a');
                    a.href = '#' + item.id;
                    a.innerHTML = `
                        <div class="search-result-title">${highlightMatches(item.title, query)}</div>
                        <div class="search-result-preview">${getContentPreview(item.content, query)}</div>
                    `;
                    a.addEventListener('click', function(e) {
                        e.preventDefault();
                        navigateToSearchResult(item);
                    });
                    
                    li.appendChild(a);
                    resultsList.appendChild(li);
                    displayedCount++;
                }
            }
            
            if (results.length > MAX_RESULTS) {
                const moreResults = document.createElement('li');
                moreResults.className = 'search-more-results';
                moreResults.textContent = `${results.length - MAX_RESULTS} more results found...`;
                resultsList.appendChild(moreResults);
            }
            
            searchResults.appendChild(resultsList);
            searchResults.style.display = 'block';
        }

        function highlightMatches(text, query) {
            if (!text) return '';
            
            const terms = query.toLowerCase().split(/\s+/).filter(term => term.length > 1);
            let result = text;
            
            terms.forEach(term => {
                const regex = new RegExp(`(${escapeRegExp(term)})`, 'gi');
                result = result.replace(regex, '<mark>$1</mark>');
            });
            
            return result;
        }

        function getContentPreview(content, query) {
            if (!content) return '';
            
            const lowerContent = content.toLowerCase();
            const terms = query.toLowerCase().split(/\s+/).filter(term => term.length > 1);
            
            // Find the best position with most matches
            let bestPos = -1;
            let bestScore = 0;
            
            for (let i = 0; i < content.length; i++) {
                let score = 0;
                for (const term of terms) {
                    if (lowerContent.substr(i, term.length) === term) {
                        score += term.length;
                    }
                }
                
                if (score > bestScore) {
                    bestScore = score;
                    bestPos = i;
                }
            }
            
            if (bestPos === -1) {
                return content.substring(0, 100) + (content.length > 100 ? '...' : '');
            }
            
            const startPos = Math.max(0, bestPos - 30);
            const endPos = Math.min(content.length, bestPos + bestScore + 70);
            let preview = content.substring(startPos, endPos);
            
            if (startPos > 0) preview = '...' + preview;
            if (endPos < content.length) preview = preview + '...';
            
            return highlightMatches(preview, query);
        }

        function navigateToSearchResult(item) {
            // Hide all pages
            pages.forEach(page => {
                page.classList.remove('active');
            });
            
            // Show the page containing the result
            const targetPage = document.getElementById(item.page);
            if (targetPage) {
                targetPage.classList.add('active');
                
                // Scroll to the element after the page is visible
                setTimeout(() => {
                    if (item.element) {
                        const currentElement = document.getElementById(item.element.id) || 
                                             document.querySelector(`[data-original-id="${item.element.id}"]`);
                        
                        if (currentElement) {
                            currentElement.scrollIntoView({
                                behavior: 'smooth',
                                block: 'center'
                            });
                            
                            // Highlight the element
                            currentElement.classList.add('search-highlight');
                            setTimeout(() => {
                                currentElement.classList.remove('search-highlight');
                            }, 3000);
                        }
                    }
                }, 50);
            }
            
            // Close search results and clear input
            searchResults.style.display = 'none';
            searchInput.value = '';
        }

        // Initialize search data
        initSearchData();

        // Watch for DOM changes to reinitialize search
        const observer = new MutationObserver((mutations) => {
            let needsUpdate = false;
            mutations.forEach(mutation => {
                if (mutation.type === 'childList') {
                    needsUpdate = true;
                }
            });
            
            if (needsUpdate) {
                initSearchData();
            }
        });
        
        // Observe all pages for changes
        document.querySelectorAll('.page').forEach(page => {
            observer.observe(page, {
                childList: true,
                subtree: true
            });
        });

        // Add debounce to input event
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                performSearch(this.value.trim());
            }, 300);
        });
        
        // Handle form submission
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            clearTimeout(searchTimeout);
            performSearch(searchInput.value.trim());
        });
        
        // Close search results when clicking outside
        document.addEventListener('click', function(e) {
            if (!searchForm.contains(e.target) && !searchResults.contains(e.target)) {
                searchResults.style.display = 'none';
            }
        });
        
        // Keyboard navigation for search results
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowDown' && searchResults.style.display === 'block') {
                e.preventDefault();
                const firstResult = searchResults.querySelector('a');
                if (firstResult) firstResult.focus();
            }
            
            if (e.key === 'Escape') {
                searchResults.style.display = 'none';
            }
        });
        
        // Handle keyboard navigation within results
        searchResults.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                const nextItem = document.activeElement.parentElement.nextElementSibling?.querySelector('a');
                if (nextItem) nextItem.focus();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                const prevItem = document.activeElement.parentElement.previousElementSibling?.querySelector('a');
                if (prevItem) {
                    prevItem.focus();
                } else {
                    searchInput.focus();
                }
            } else if (e.key === 'Enter') {
                e.preventDefault();
                document.activeElement.click();
            }
        });
    }

    // ===== GLOBAL FUNCTIONS =====
    window.editProduct = function(index) {
        if (!isLoggedIn) {
            showToast('Please login as admin first', true);
            return;
        }

        const products = JSON.parse(localStorage.getItem('domwood-products')) || [];
        const product = products[index];
        if (!product) return;
        
        if (productNameInput) productNameInput.value = product.name;
        if (productDescInput) productDescInput.value = product.description;
        if (productCategoryInput) productCategoryInput.value = product.category;
        if (productPriceInput) productPriceInput.value = product.price;
        
        showToast(`Editing ${product.name}`);
    };

    window.deleteProduct = function(index) {
        if (!isLoggedIn) {
            showToast('Please login as admin first', true);
            return;
        }

        const products = JSON.parse(localStorage.getItem('domwood-products')) || [];
        if (index >= 0 && index < products.length) {
            const deleted = products.splice(index, 1);
            localStorage.setItem('domwood-products', JSON.stringify(products));
            loadProducts();
            loadProductPreview();
            loadProductsPage();
            showToast(`Deleted ${deleted[0].name}`);
        }
    };

    window.deleteImage = function(category, index) {
        if (!isLoggedIn) {
            showToast('Please login as admin first', true);
            return;
        }

        const images = JSON.parse(localStorage.getItem('domwood-images')) || {};
        if (images[category] && index >= 0 && index < images[category].length) {
            images[category].splice(index, 1);
            localStorage.setItem('domwood-images', JSON.stringify(images));
            loadGalleryImages(category);
            showToast('Image deleted');
        }
    };

    // ===== INITIALIZATION =====
    initAdminPanel();
    initMainWebsite();
});